from django.apps import AppConfig


class MomoConfig(AppConfig):
    name = "momo"
