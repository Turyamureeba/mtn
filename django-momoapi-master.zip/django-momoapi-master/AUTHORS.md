# Authors for the Django MoMo API App. 

- Mwanja Joel [(@mrmwanjajoel)](https://twitter.com/mrjoelmwanja)

- Arthur Nangai [(@arthurnangai)](https://twitter.com/arthurnangai)