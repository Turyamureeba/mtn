import pytest

# create a simple Pytest 
def test_user_create():
    pass